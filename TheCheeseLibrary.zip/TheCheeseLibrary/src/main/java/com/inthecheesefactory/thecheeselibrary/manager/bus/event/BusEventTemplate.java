package com.inthecheesefactory.thecheeselibrary.manager.bus.event;

/**
 * Created by nuuneoi on 12/4/2014.
 */
public class BusEventTemplate {

    private int param1;

    public BusEventTemplate(int param1) {
        this.param1 = param1;
    }

    public int getParam1() {
        return param1;
    }

    public void setParam1(int param1) {
        this.param1 = param1;
    }
}
