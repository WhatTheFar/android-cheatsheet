# TheCheeseLibrary

Android module used in my Android Application Development course featuring FragmentTemplate, CustomViewTemplate, CustomViewGroupTemplate, Otto eventbus and etc.

![](https://raw.githubusercontent.com/nuuneoi/TheCheeseLibrary/master/screenshot.png)
